//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//pay off 75,000 student loans in 20 years
//$312.5 per month
//countdown to payoff

var monthlyPayment: () -> Double = {
    return (75000/20)/12
    
}
monthlyPayment()

var amount: Double = 3750/12
var currentBalance:Double = 75000

func paymentSchedule () -> Double{
    currentBalance -= monthlyPayment()
    return currentBalance

}

while currentBalance > 0 {
    print(paymentSchedule())

}


